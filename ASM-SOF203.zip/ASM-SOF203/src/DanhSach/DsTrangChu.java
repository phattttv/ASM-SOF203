/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DanhSach;

/**
 *
 * @author trinh
 */
public class DsTrangChu {
    private String Ma;
    private String hoten;
    private int thoigian;
    private int songay;
    private int thangnam;
    private float luong;

    public DsTrangChu() {
    }

    public DsTrangChu(String Ma, String hoten, int thoigian, int songay, int thangnam, float luong) {
        this.Ma = Ma;
        this.hoten = hoten;
        this.thoigian = thoigian;
        this.songay = songay;
        this.thangnam = thangnam;
        this.luong = luong;
    }

    
    
    public String getMa() {
        return Ma;
    }

    public void setMa(String Ma) {
        this.Ma = Ma;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public int getThoigian() {
        return thoigian;
    }

    public void setThoigian(int thoigian) {
        this.thoigian = thoigian;
    }

    public int getSongay() {
        return songay;
    }

    public void setSongay(int songay) {
        this.songay = songay;
    }

    public int getThangnam() {
        return thangnam;
    }

    public void setThangnam(int thangnam) {
        this.thangnam = thangnam;
    }

    public float getLuong() {
        return luong;
    }

    public void setLuong(float luong) {
        this.luong = luong;
    }
    
    
}
